import React from "react";
import web from "./Images/Vector.jpeg";

function App() {
  return (
    <>
      <div
        style={{
          backgroundColor: "lightblue",
          minHeight: "100vh",
        }}
      >
        <main
          style={{
            height: "80vh",
            display: "flex",
            justifyContent: "space-around",
            alignItem: "center",
          }}
        >
          <div
            style={{
              height: 300,
              width: 400,
              position: "absolute",
              left: 0,
              width: 500,
              paddingTop: 200,
              paddingLeft: 200,
            }}
          >
            <h1>Hello and Welcome!</h1>
            <h3>This is the start of your new journey</h3>
            <div style={{ left: 0 }}>
              <button
                style={{
                  backgroundColor: "dodgerblue",
                  color: "white",
                  fontSize: 15,
                  padding: 10,
                  borderRadius: 30,
                  cursor: "pointer",
                  textAlign: "center",
                  margin: "auto",
                  content: "center",
                  padding: 10,
                }}
              >
                Get Started
              </button>
            </div>
          </div>
          <div>
            <img
              src={web}
              style={{
                maxWidth: 300,
                height: "auto",
                position: "absolute",
                paddingTop: 200,
                paddingLeft: 100,
              }}
            />
          </div>
        </main>
      </div>
    </>
  );
}

export default App;
